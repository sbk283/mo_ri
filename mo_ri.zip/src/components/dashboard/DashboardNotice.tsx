const DashboardNotice = () => {
  return <div>DashboardNotice</div>;
};

export default DashboardNotice;
