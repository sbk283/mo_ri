export const homeBanners = [
  {
    id: 1,
    imageUrl: '/modalbanner1.jpg',
    title: '',
    description: '',
    link: '/serviceint',
  },
  {
    id: 2,
    imageUrl: '/modalbanner2.jpg',
    title: '',
    description: '',
    link: '/grouplist/all',
  },
  {
    id: 3,
    imageUrl: '/modalbanner3.jpg',
    title: '',
    description: '',
    link: '/creategroup',
  },
  {
    id: 4,
    imageUrl: '/modalbanner4.jpg',
    title: '',
    description: '',
    link: '/reviews',
  },
  {
    id: 5,
    imageUrl: '/modalbanner5.jpg',
    title: '',
    description: '',
    link: '/mypage',
  },
  {
    id: 6,
    imageUrl: '/modalbanner6.jpg',
    title: '',
    description: '',
    link: '',
  },
];
