import { useState, useCallback, useEffect } from 'react';
import html2pdf from 'html2pdf.js';
import ReactDOMServer from 'react-dom/server';
import PDFPreview from './PDFPreview';
import { supabase } from '../../lib/supabase';

export function usePDFPrintHandler() {
  const [isPrinting, setIsPrinting] = useState(false);
  const [profile, setProfile] = useState<{ name: string; email: string } | null>(null);

  useEffect(() => {
    const fetchProfile = async () => {
      const { data: authData } = await supabase.auth.getUser();
      const user = authData?.user;
      if (!user) return;

      const { data, error } = await supabase
        .from('user_profiles')
        .select('name, email')
        .eq('user_id', user.id)
        .single();

      if (!error && data) setProfile({ name: data.name, email: data.email });
    };
    fetchProfile();
  }, []);

  const printSelectedItems = useCallback(
    async (allMeetings: any[], selectedIds: string[]) => {
      if (!selectedIds || selectedIds.length === 0) {
        alert('출력할 항목을 선택해주세요.');
        return;
      }

      try {
        setIsPrinting(true);

        const selectedMeetings = allMeetings
          .filter(m => selectedIds.includes(m.id))
          .map(m => ({
            ...m,
            curriculum:
              typeof m.curriculum === 'string'
                ? m.curriculum
                    .split(',')
                    .map((c: string) => c.trim())
                    .filter(Boolean)
                : Array.isArray(m.curriculum)
                  ? m.curriculum
                  : [],
          }));

        if (selectedMeetings.length === 0) {
          alert('선택된 모임이 없습니다.');
          setIsPrinting(false);
          return;
        }

        // PDF용 임시 컨테이너 생성
        const container = document.createElement('div');
        container.style.position = 'absolute';
        container.style.left = '-9999px';
        container.style.top = '0';
        container.style.width = '210mm'; // A4 너비
        document.body.appendChild(container);

        // React 컴포넌트를 HTML 문자열로 변환
        container.innerHTML = ReactDOMServer.renderToStaticMarkup(
          <PDFPreview items={selectedMeetings} profile={profile} />,
        );

        // 렌더 안정화
        await new Promise(res => setTimeout(res, 200));

        const options = {
          margin: [10, 10, 10, 10] as [number, number, number, number],
          filename: '참여이력.pdf',
          image: { type: 'jpeg' as 'jpeg', quality: 0.98 },
          html2canvas: {
            scale: 2,
            useCORS: true,
            letterRendering: true,
            backgroundColor: '#ffffff',
          },
          jsPDF: {
            unit: 'mm',
            format: 'a4',
            orientation: 'portrait' as 'portrait',
          },
          pagebreak: {
            mode: ['avoid-all', 'css', 'legacy'],
            before: '.page-break-before',
            after: '.page-break-after',
            avoid: '.avoid-break',
          },
        };

        await html2pdf().set(options).from(container).save();

        document.body.removeChild(container);
      } catch (err) {
        console.error('PDF 생성 오류:', err);
        alert('PDF 출력 중 문제가 발생했습니다.');
      } finally {
        setIsPrinting(false);
      }
    },
    [profile],
  );

  return { printSelectedItems, isPrinting };
}
