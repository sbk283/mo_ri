import type { GroupWithCategory } from '../../types/group';

interface PDFPreviewProps {
  items: GroupWithCategory[];
  profile: { name: string; email: string } | null;
}

export default function PDFPreview({ items, profile }: PDFPreviewProps) {
  return (
    <div className="p-10 bg-white">
      {/* 첫 페이지 - 기본 정보 */}
      <div className="avoid-break">
        <div className="mb-[30px]">
          <h1 className="text-[22px] font-semibold">모임 참여 이력 증명서</h1>
          <p className="text-sm">출력일: {new Date().toLocaleDateString()}</p>
        </div>

        {/* 프로필 정보 */}
        <div className="p-4">
          <div className="text-lg font-semibold mb-[20px] ml-[20px]">프로필 정보</div>
          <div className="border-b-[2px] border-gray-200 mb-[7px]" />
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="text-md font-semibold mb-[20px] ml-[20px] pl-[20px]">성 명</div>
              <div className="text-md font-semibold mb-[20px] ml-[60px]">
                {' '}
                {profile?.name ?? '-'}
              </div>
            </div>
            <div className="flex items-center">
              <div className="text-md font-semibold mb-[20px]">이메일</div>
              <div className="text-md font-semibold mb-[20px] ml-[40px] pr-[150px]">
                {profile?.email ?? '-'}
              </div>
            </div>
          </div>
          <div className="border-b border-gray-200 mb-[20px]" />
        </div>

        {/* 모임 참여 이력 */}
        <div className="p-4 w-full">
          <div className="text-lg font-semibold mb-[20px] ml-[20px]">모임 참여 이력</div>
          <div className="border-b-[2px] border-gray-200 mb-[7px]" />
          <div className="grid grid-cols-[20%_60%_20%] w-full mb-[20px]">
            <div className="text-md font-semibold text-center">모임 기간</div>
            <div className="text-md font-semibold text-center">모임 이름</div>
            <div className="text-md font-semibold text-center">모임 분류</div>
          </div>
          <div className="border-b border-gray-200" />

          <div className="flex flex-col">
            {items.map((item, index) => (
              <div key={index} className="flex w-full items-center border-b border-gray-200 py-2">
                <div className="w-1/5 text-sm font-normal text-center">
                  {item.group_start_day} ~ {item.group_end_day}
                </div>
                <div className="w-3/5 text-base font-semibold text-center">{item.group_title}</div>
                <div className="w-1/5 text-base font-semibold text-center">
                  {item.categories_major?.category_major_name ?? '-'} {'>'}
                  {item.categories_sub?.category_sub_name ?? '-'}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 페이지 넘김 */}
      <div className="page-break-after"></div>

      {/* 모임 세부 정보 - 각 항목마다 페이지 넘김 방지 */}
      <div className="p-4 w-full">
        <div className="text-lg font-semibold mb-[20px] ml-[20px]">모임 세부 정보</div>
        {items.map((item, index) => (
          <div className="border p-3 rounded-sm mb-[20px] avoid-break" key={index}>
            <div className="flex justify-between pb-[20px]">
              <div className="flex">
                <div className="text-md font-semibold ml-[20px] pl-[20px]">모임기간</div>
                <div className="text-md font-semibold ml-[60px]">
                  {item.group_start_day} ~ {item.group_end_day}
                </div>
              </div>
              <div className="flex">
                <div className="text-md font-semibold">모임 분류</div>
                <div className="text-md font-semibold ml-[40px] pr-[150px]">
                  {' '}
                  {item.categories_major?.category_major_name ?? '-'}
                  {'>'}
                  {item.categories_sub?.category_sub_name ?? '-'}
                </div>
              </div>
            </div>

            <div className="border-b border-gray-200 mb-[10px]" />
            <div className="flex pb-[20px]">
              <div className="text-md font-semibold ml-[20px] pl-[20px]">모임 이름</div>
              <div className="text-md font-semibold ml-[56px]">{item.group_title}</div>
            </div>

            <div className="border-b border-gray-200 mb-[10px]" />
            <div className="flex pb-[20px]">
              <div className="text-md font-semibold ml-[20px] pl-[20px]">커리큘럼</div>
              <div>
                {(() => {
                  if (!item.curriculum) {
                    return (
                      <div className="text-md font-normal ml-[56px] text-gray-400">
                        커리큘럼 없음
                      </div>
                    );
                  }

                  let curriculumArray: { title?: string; detail?: string }[] = [];

                  try {
                    let parsed = item.curriculum;

                    if (typeof item.curriculum === 'string') {
                      parsed = JSON.parse(item.curriculum);
                    }

                    if (Array.isArray(parsed)) {
                      curriculumArray = parsed
                        .filter(
                          (c): c is { title?: string; detail?: string; files?: any } =>
                            typeof c === 'object' && c !== null,
                        )
                        .map(c => ({
                          title: c.title ?? '-',
                          detail: c.detail ?? '-',
                        }));
                    }
                  } catch (e) {
                    console.error('커리큘럼 파싱 에러:', e);
                    return (
                      <div className="text-md font-normal ml-[56px] text-gray-400">
                        커리큘럼 없음
                      </div>
                    );
                  }

                  if (curriculumArray.length === 0) {
                    return (
                      <div className="text-md font-normal ml-[56px] text-gray-400">
                        커리큘럼 없음
                      </div>
                    );
                  }

                  curriculumArray.sort((a, b) => a.title!.localeCompare(b.title!));

                  return curriculumArray.map((c, idx) => (
                    <div key={idx} className="text-md font-normal ml-[56px] mb-2">
                      {idx + 1}. {c.title}
                      <div className="text-gray-600 ml-[10px]">{c.detail}</div>
                    </div>
                  ));
                })()}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
