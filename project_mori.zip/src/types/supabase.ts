Need to install the following packages:
supabase@2.51.0
Ok to proceed? (y)
