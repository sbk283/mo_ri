import GroupDashboardLayout from '../components/layout/GroupDashboardLayout';

function GroupContentPage() {
  return (
    <GroupDashboardLayout>
      <div className="bg-white shadow-card h-[770px]">GroupContentPage</div>
    </GroupDashboardLayout>
  );
}

export default GroupContentPage;
