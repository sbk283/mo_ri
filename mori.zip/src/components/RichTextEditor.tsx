// editor 컴포넌트

import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';

const RichTextEditor = () => {
  return (
    <div>
      <ReactQuill />
    </div>
  );
};

export default RichTextEditor;
